# GitHub Pages frontend

Upload `index.html` to GitHub Pages.

Before publishing, replace:
`const API_BASE = window.DPT_API_BASE || "http://localhost:8787";`
with your deployed backend URL, for example:
`const API_BASE = "https://YOUR-BACKEND-DOMAIN";`

Never put OpenAI or Copyleaks API keys in this file.
